<?php
/**
 * This file is here to prevent breaking.
 *
 * @package Stanley
 * @since 1.0.0
 */

_e( 'Enable full site editing to view this theme.', 'stanley' );
