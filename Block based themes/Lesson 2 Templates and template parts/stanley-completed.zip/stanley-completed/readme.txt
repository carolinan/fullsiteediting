=== Stanley ===
Contributors: poena
Requires at least: 5.4
Tested up to: 5.4
Requires PHP: 7.0
License: GNU General Public License v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Copyright: Carolina Nymark

Short description

== Description ==


== Installation ==
1. Unzip `stanley.zip` to the `/wp-content/themes/` directory
2. Activate the theme through the 'Appearance' menu in WordPress
3. Install and activate the Gutenberg Plugin
4. Enable Full Site Editing from the Gutenberg experimental settings.

== Change log ==

Version 1.0.0
Release

== Resources Used In This Theme ==
Stanley is based on Default, GPL v2, Copyright WordPress.org