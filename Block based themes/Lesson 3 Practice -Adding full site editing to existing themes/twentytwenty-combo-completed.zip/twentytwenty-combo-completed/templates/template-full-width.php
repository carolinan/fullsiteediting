<?php
/**
 * Template Name: Full Width Template
 * Template Post Type: post, page
 *
 * @package Twenty_Twenty_Combo
 * @since Twenty Twenty Combo 1.0
 */

get_template_part( 'singular' );
